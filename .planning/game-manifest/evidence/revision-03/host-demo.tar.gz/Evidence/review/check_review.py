"""Independent final review of document/provenance/coordination only; runtime not_run."""
from pathlib import Path
from collections import deque
import hashlib,json,os,re,subprocess,sys

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'Evidence/review'
ACTOR='/root/demo_reviewer'
TASKS=('design-loop','design-level')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def protected():
    return {p.relative_to(ROOT).as_posix():sha(p) for p in ROOT.rglob('*')
            if p.is_file() and not p.is_symlink() and not p.is_relative_to(OUT)}

def file(relative):
    path=Path(relative)
    assert relative and not path.is_absolute() and '..' not in path.parts and '\\' not in relative
    full=ROOT
    for part in path.parts:
        full=full/part
        assert not full.is_symlink()
    assert full.is_file() and full.stat().st_size>0,relative
    return full

def covered(relative,scopes):
    p=Path(relative)
    return any(p==Path(scope) or Path(scope) in p.parents for scope in scopes)

before=protected()
state=json.loads(file('.game-design/state/parallel.json').read_text())
assert state['mode']=='design-only'
assert state['tasks']['design-package']['status']=='pending'
assert set(state['tasks']['design-package']['depends_on'])==set(TASKS)
# No premature review or successor release has happened before this independent actor returns.
assert all(state['tasks'][tid]['status']=='validated' for tid in TASKS)
authors=[];hashes={}
for tid in TASKS:
    task=state['tasks'][tid]
    order=json.loads(file('orders/'+tid+'.json').read_text())
    author=json.loads(file('Evidence/'+tid+'/result.json').read_text())
    integrator=task['stages']['integrate']['actor'];qa=task['stages']['validate']['actor']
    identities=(task['run_id'],integrator,qa,ACTOR)
    assert len(set(identities))==4,identities
    authors.append(task['run_id'])
    assert set(task['stages'])=={'integrate','validate'}
    assert task['stages']['integrate']['decision']=='integrated'
    assert task['stages']['validate']['decision']=='pass'
    assert task['role']=='game-design-designer' and task['effect']=='design'
    assert task['id']==order['id']==author['task_id']==tid
    assert task['claim_token']==order['claim_token']==author['claim_token']
    assert order['attempt']==task['attempt']==1 and task['run_id']
    assert task['writes']==order['writes'] and task['workspace']==str(ROOT)
    for path,expected in task['input_hashes'].items():assert sha(file(path))==expected==order['input_hashes'][path]
    for path,expected in task['artifact_hashes'].items():
        assert covered(path,task['writes'])
        assert sha(file(path))==expected
    assert {item['path']:item['sha256'] for item in author['artifacts']}==task['artifact_hashes']
    assert set(task['outputs'])<=task['artifact_hashes'].keys()
    assert author['status']=='submitted' and author['tests']
    assert all(t['status']=='pass' and t['exit_status']==0 for t in author['tests'])
    assert task['result']['tests']==author['tests']
    assert set(author['evidence'])=={ref['path'] for ref in task['result']['verified_evidence']}
    for ref in task['result']['verified_evidence']:
        assert covered(ref['path'],task['writes']) and sha(file(ref['path']))==ref['sha256']
    for name,stage in task['stages'].items():
        assert stage['artifact_hashes']==task['artifact_hashes']
        ref=stage['evidence'];assert sha(file(ref['path']))==ref['sha256']
        record=json.loads(file(ref['path']).read_text())
        assert record['actor']==stage['actor'] and record['exit_status']==0
        assert sha(file(record['command'][1]))==record['script_sha256']
        assert record['stderr']==''
        assert 'not_run' in record['scope'] or record.get('runtime_validation')=='not_run' or 'no engine/game/DCC/device execution' in record['scope']
    for gate_id in task['gates']:
        gate=state['gates'][gate_id];assert gate['status']=='approved'
        ref=gate['evidence'];assert sha(file(ref['path']))==ref['sha256']
    hashes[tid]=dict(task['artifact_hashes'])
    print(f'PASS {tid}: author/integrator/QA/reviewer independent; validated state; token/attempt/scope/input/artifact/proof hashes match')
assert len(set(authors))==2
print('PASS design-only gates: no implementation or release approval claimed; successor still pending until review')

qa_record=json.loads(file('Evidence/qa/check.txt').read_text())
for expected in ('787 reachable states','3148 direction transitions','UURURD','only one entering-win event','initial crate-on-goal','runtime_validation'):
    # The final JSON uses engine_game_device_validation, not generic runtime_validation.
    if expected=='runtime_validation':assert qa_record.get('runtime_validation')=='not_run'
    else:assert expected in qa_record['stdout'],expected
assert qa_record['tasks']=={tid:'pass' for tid in TASKS}
assert 'engine_game_device_validation' in qa_record['stdout']
print('PASS QA evidence scope: literal commands/exit0 and reachable-state exploration retained; engine/game/DCC/device not_run')

# The author and integration checks are currently rerunnable. The QA checker deliberately
# expects the pre-validation integrated phase, so audit its frozen execution record instead
# of altering shared state merely to re-run a phase-specific assertion.
for script in ('Evidence/design-loop/check_spec.py','Evidence/design-level/validate_level.py','Evidence/integration/check_integration.py'):
    command=[sys.executable,script]
    run=subprocess.run(command,cwd=ROOT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},
                       input='',capture_output=True,text=True)
    print(json.dumps({'command':command,'cwd':str(ROOT),'stdin':'','stdout':run.stdout,
                      'stderr':run.stderr,'exit_status':run.returncode},ensure_ascii=False))
    assert run.returncode==0 and not run.stderr
print('PASS reviewer actual reruns: both author scripts and integration script exit0, original logs retained')

core=file('Design/core-loop.md').read_text();level=file('Design/level-outline.md').read_text()
for phrase in ('player=(row,col)','crate==goal','不允许拉箱','history=[]','方向动作只在won=false时处理','Z/R在胜利后仍可使用'):assert phrase in core
for phrase in ('`x` 向右增加、`y` 向下增加','没有拉箱命令或自动拉回行为','清空撤销历史','核心循环规格统一决定'):assert phrase in level
board=re.search(r'```grid\n(.*?)\n```',level,re.S).group(1).splitlines()
route=''.join(re.search(r'Solution: `([^`]+)`',level).group(1).split());assert route=='UURURD'
find=lambda symbol:[complex(x,y) for y,row in enumerate(board) for x,c in enumerate(row) if c==symbol]
assert len(board)==7 and all(len(row)==8 for row in board)
assert all(len(find(symbol))==1 for symbol in '@$G')
p0,b0,g=(find(symbol)[0] for symbol in '@$G')
assert (p0,b0,g)==(complex(2,4),complex(3,2),complex(4,3))
clear={complex(x,y) for y,row in enumerate(board) for x,c in enumerate(row) if c!='#'}
directions={'U':-1j,'D':1j,'R':1,'L':-1}
# A third representation (complex x+iy) independently checks route and transition invariants.
def step(p,b,action):
    if b==g or action not in directions:return p,b,False
    d=directions[action];candidate=p+d
    if candidate not in clear:return p,b,False
    box=b+d if candidate==b else b
    if box not in clear:return p,b,False
    return candidate,box,True

queue=deque([(p0,b0)]);seen={(p0,b0)};transitions=0
while queue:
    p,b=queue.popleft()
    for direction in directions:
        np,nb,changed=step(p,b,direction);transitions+=1
        assert np in clear and nb in clear and np!=nb
        if changed:
            assert np-p==directions[direction]
            assert nb==b or nb-b==directions[direction]
            if nb!=b:assert np==b # Pushing enters old box cell, never pulling.
        else:assert (np,nb)==(p,b)
        if b==g:assert not changed
        if (np,nb) not in seen:seen.add((np,nb));queue.append((np,nb))
assert len(seen)==787 and transitions==3148
p,b=p0,b0;history=[];count=0
for i,action in enumerate(route,1):
    np,nb,changed=step(p,b,action);assert changed
    history.append((p,b,count,b==g));p,b=np,nb;count+=1
    assert (b==g)==(i==6)
assert (p,b,count)==(complex(4,2),g,6)
for action in directions:assert step(p,b,action)==(p,b,False)
p,b,count,won=history.pop();assert (p,b,count,won)==(complex(4,1),complex(4,2),5,False)
p,b,count,history=p0,b0,0,[];assert b!=g and not history
print('PASS independent complex-coordinate model: 787 states / 3148 transitions; UURURD, push-only, win-freeze, undo and reset agree')
assert protected()==before,'review or re-run changed protected bytes outside assigned Evidence/review/'
print('PASS readonly reviewer scope: all original/author/integration/QA/shared state files byte-identical')
print(json.dumps({'actor':ACTOR,'tasks':{tid:'pass' for tid in TASKS},'reviewed_artifact_hashes':hashes,
                  'reviewed_status':'validated','successor_status_before_review':'pending',
                  'coordinate_states':len(seen),'coordinate_transitions':transitions,
                  'limitations':['Design documents and independent Python rule simulation only.',
                                 'QA original command is phase-specific; its frozen integrated-phase record was audited, not rewritten/replayed in the validated phase.',
                                 'No engine, actual game, DCC, device or human-playtest acceptance.'],
                  'engine_game_DCC_device_validation':'not_run'},ensure_ascii=False,indent=2))
