from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[2]
job=json.loads((root/'orders/design-loop.json').read_text())
brief=root/'Brief.md'
assert hashlib.sha256(brief.read_bytes()).hexdigest()==job['input_hashes']['Brief.md'], 'readonly brief baseline changed'
text=(root/'Design/core-loop.md').read_text()
headings=['## 目标与核心循环','## 状态与输入','## 移动规则','## 推箱规则','## 撤销规则','## 重置规则','## 胜利与反馈','## 边界验收','## 交接与验证边界']
for heading in headings:assert heading in text, 'missing section: '+heading
rules=['REQ-MOVE','REQ-PUSH','REQ-UNDO','REQ-RESET','REQ-WIN','不允许拉箱','整个推动仅计一步','history=[]','crate==goal','地图边界','not_run']
for rule in rules:assert rule in text, 'missing rule: '+rule
cases=['TEST-MOVE-01','TEST-MOVE-02','TEST-PUSH-01','TEST-PUSH-02','TEST-UNDO-01','TEST-UNDO-02','TEST-RESET-01','TEST-WIN-01','TEST-WIN-02','TEST-WIN-03']
for case in cases:assert case in text, 'missing acceptance case: '+case
print('PASS readonly Brief.md SHA-256 matches claim baseline')
print('PASS 9 required document sections')
print('PASS 11 required rule/verification statements')
print('PASS 10 named boundary acceptance cases')
print('SCOPE document assertions only; engine/gameplay/DCC/device execution not_run')
