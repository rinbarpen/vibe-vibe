"""Independent design-document and Python rule-model QA; no game/engine/device run."""
from collections import deque
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
ACTOR='/root/parallel_tests'
TASKS=('design-loop','design-level')
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()

def protected():
    return {p.relative_to(ROOT).as_posix():sha(p) for p in ROOT.rglob('*')
            if p.is_file() and not p.is_symlink() and not p.is_relative_to(ROOT/'Evidence/qa')}

before=protected()
state=json.loads((ROOT/'.game-design/state/parallel.json').read_text())
assert state['mode']=='design-only'
for identifier in TASKS:
    task=state['tasks'][identifier]
    assert task['status']=='integrated', (identifier,task['status'])
    assert task['run_id']!=ACTOR and task['stages']['integrate']['actor']!=ACTOR
    for path,expected in task['artifact_hashes'].items():assert sha(ROOT/path)==expected
    for path,expected in task['input_hashes'].items():assert sha(ROOT/path)==expected
    for entry in task['result']['verified_evidence']:assert sha(ROOT/entry['path'])==entry['sha256']
    entry=task['stages']['integrate']['evidence'];assert sha(ROOT/entry['path'])==entry['sha256']
print('PASS frozen inputs, artifacts, author evidence, integrated stage evidence and independent QA identity')

for script in ('Evidence/design-loop/check_spec.py', 'Evidence/design-level/validate_level.py',
               'Evidence/integration/check_integration.py'):
    command=[sys.executable,script]
    run=subprocess.run(command,cwd=ROOT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},
                       input='',capture_output=True,text=True)
    print(json.dumps({'command':command,'cwd':str(ROOT),'stdin':'','stdout':run.stdout,
                      'stderr':run.stderr,'exit_status':run.returncode},ensure_ascii=False))
    assert run.returncode==0, (command,run.stdout,run.stderr)
print('PASS actual rerun of both author checkers and integration checker; original outputs not overwritten')

core=(ROOT/'Design/core-loop.md').read_text(encoding='utf-8')
level=(ROOT/'Design/level-outline.md').read_text(encoding='utf-8')
assert 'player=(row,col)' in core
assert '`x` 向右增加、`y` 向下增加' in level
assert '不允许拉箱' in core and '没有拉箱命令或自动拉回行为' in level
assert '移动是否冻结由核心循环规格统一决定' in level and '方向动作只在won=false时处理' in core
assert 'Z/R在胜利后仍可使用' in core
for marker in ('REQ-MOVE','REQ-PUSH','REQ-UNDO','REQ-RESET','REQ-WIN'):assert marker in core

grid=re.search(r'```grid\n(.*?)\n```',level,re.S).group(1).splitlines()
sequence=''.join(re.search(r'Solution: `([^`]+)`',level).group(1).split())
assert sequence=='UURURD'
height=len(grid);width=len(grid[0]);assert (width,height)==(8,7) and all(len(row)==width for row in grid)
rc=lambda symbol:[(r,c) for r,row in enumerate(grid) for c,value in enumerate(row) if value==symbol]
xy=lambda symbol:[(x,y) for y,row in enumerate(grid) for x,value in enumerate(row) if value==symbol]
assert all(len(rc(symbol))==1 for symbol in '@$G')
player,crate,goal=(rc(symbol)[0] for symbol in '@$G')
player_xy,crate_xy,goal_xy=(xy(symbol)[0] for symbol in '@$G')
assert (player_xy,crate_xy,goal_xy)==((2,4),(3,2),(4,3))
assert (player,crate,goal)==((4,2),(2,3),(3,4))
walls=set(rc('#'))
d_rc={'U':(-1,0),'R':(0,1),'D':(1,0),'L':(0,-1)}
d_xy={'U':(0,-1),'R':(1,0),'D':(0,1),'L':(-1,0)}
for direction in d_rc:assert d_rc[direction]==tuple(reversed(d_xy[direction]))

def move_rc(position,box,action,*,board=grid,target_goal=goal):
    if box==target_goal or action not in d_rc:return (position,box),False
    dr,dc=d_rc[action];candidate=(position[0]+dr,position[1]+dc)
    def clear(cell):return 0<=cell[0]<len(board) and 0<=cell[1]<len(board[0]) and board[cell[0]][cell[1]]!='#'
    if not clear(candidate):return (position,box),False
    destination=box
    if candidate==box:
        destination=(box[0]+dr,box[1]+dc)
        if not clear(destination):return (position,box),False
    return (candidate,destination),True

def move_xy(position,box,action):
    # Independently expressed level-space interpreter; no reuse of rc transition.
    if box==goal_xy or action not in d_xy:return (position,box),False
    dx,dy=d_xy[action];x,y=position;next_x,next_y=x+dx,y+dy
    if not (0<=next_x<width and 0<=next_y<height) or grid[next_y][next_x]=='#':return (position,box),False
    next_box=box
    if (next_x,next_y)==box:
        bx,by=box[0]+dx,box[1]+dy
        if bx<0 or bx>=width or by<0 or by>=height or grid[by][bx]=='#':return (position,box),False
        next_box=(bx,by)
    return ((next_x,next_y),next_box),True

# All reachable position/box states, not only the documented route, must agree under (r,c)=(y,x).
queue=deque([(player,crate)]);seen={(player,crate)};transitions=0
while queue:
    position,box=queue.popleft()
    assert position!=box and position not in walls and box not in walls
    for action in 'URDL':
        new_rc,changed=move_rc(position,box,action)
        new_xy,xy_changed=move_xy(tuple(reversed(position)),tuple(reversed(box)),action)
        assert changed==xy_changed
        assert new_rc==tuple(tuple(reversed(cell)) for cell in new_xy)
        transitions+=1
        if new_rc not in seen:seen.add(new_rc);queue.append(new_rc)
print(f'PASS coordinate adapter on {len(seen)} reachable states / {transitions} direction transitions: (row,col)=(y,x)')

class RuleModel:
    def __init__(self,initial_player=player,initial_box=crate,target=goal):
        self.initial=(initial_player,initial_box,target);self.reset()
    def snapshot(self):return self.player,self.box,self.count,self.won,tuple(self.history)
    def reset(self):
        self.player,self.box,self.target=self.initial;self.count=0;self.won=self.box==self.target;self.history=[];self.win_events=0
    def move(self,action):
        old=(self.player,self.box,self.count,self.won)
        (new_player,new_box),changed=move_rc(self.player,self.box,action,target_goal=self.target)
        if not changed:return False
        self.history.append(old);self.player,self.box=new_player,new_box;self.count+=1
        self.won=self.box==self.target
        if self.won and not old[-1]:self.win_events+=1
        return True
    def undo(self):
        if not self.history:return False
        self.player,self.box,self.count,self.won=self.history.pop();return True

expected_xy=[((2,4),(3,2)),((2,3),(3,2)),((2,2),(3,2)),((3,2),(4,2)),
             ((3,1),(4,2)),((4,1),(4,2)),((4,2),(4,3))]
m=RuleModel()
for step,action in enumerate(sequence,1):
    assert m.move(action)
    assert (tuple(reversed(m.player)),tuple(reversed(m.box)))==expected_xy[step]
    assert m.count==len(m.history)==step and m.won==(step==6)
print('PASS UURURD: exact six documented positions, each successful action = one move + one undo snapshot; last step wins')
winning=m.snapshot()
for action in 'URDL':assert not m.move(action) and m.snapshot()==winning
assert m.win_events==1
print('PASS won state freezes all direction actions; only one entering-win event in the route')
assert m.undo() and (m.player,m.box,m.count,m.won)==((1,4),(2,4),5,False)
assert m.move('D') and m.won
m.reset();initial=m.snapshot();assert not m.history and not m.undo() and m.snapshot()==initial
print('PASS undo restores player/crate/count/won, then replay works; reset clears history and empty undo is a no-op')
assert m.move('U');before_blocked=m.snapshot();assert not m.move('R') and m.snapshot()==before_blocked
assert m.undo() and m.snapshot()==initial
m.reset()
for action in 'UUUR':assert m.move(action)
before_blocked=m.snapshot();assert not m.move('D') and m.snapshot()==before_blocked
print('PASS blocked walk/push preserve all state and do not consume undo history')
m.reset()
for action in 'UUR':assert m.move(action)
box_before=m.box;assert m.move('L') and m.box==box_before
before_unknown=m.snapshot();assert not m.move('PULL') and m.snapshot()==before_unknown
assert not m.move('UR') and m.snapshot()==before_unknown
print('PASS no pull or diagonal action; stepping away never moves the crate')
# Explicit open-edge fixtures cover generic finite-board bounds, not only this level's sealed walls.
open_board=['..','..']
assert move_rc((0,0),(1,1),'U',board=open_board,target_goal=(1,0))==(((0,0),(1,1)),False)
assert move_rc((0,0),(1,1),'L',board=open_board,target_goal=(1,0))==(((0,0),(1,1)),False)
assert move_rc((0,0),(0,1),'R',board=open_board,target_goal=(1,1))==(((0,0),(0,1)),False)
assert not RuleModel(initial_player=goal,initial_box=crate,target=goal).won
already=RuleModel(initial_player=player,initial_box=goal,target=goal)
assert already.won and not already.move('U');already.reset();assert already.won
print('PASS finite map edges and push-beyond-edge block atomically; player-on-goal is not success; initial crate-on-goal recomputes won')
assert protected()==before,'QA or rerun wrote outside Evidence/qa/'
assert all(state['tasks'][identifier]['status']=='integrated' for identifier in TASKS)
print('PASS readonly scope: shared state, Brief, orders, Design, author/integration scripts and evidence unchanged')
print(json.dumps({'actor':ACTOR,'tasks':{identifier:'pass' for identifier in TASKS},
                  'artifact_hashes':{identifier:state['tasks'][identifier]['artifact_hashes'] for identifier in TASKS},
                  'coordinate_states':len(seen),'coordinate_transitions':transitions,
                  'scope':'design documents + independent Python rule simulation only',
                  'engine_game_device_validation':'not_run'},ensure_ascii=False,indent=2))
