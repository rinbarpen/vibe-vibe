"""Independent design integration checks only; engine/game/DCC/device runtime not_run."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
ACTOR='/root/native_roles'
TASKS=('design-loop','design-level')
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()


def local(value):
    assert isinstance(value,str) and value and '\\' not in value
    relative=Path(value)
    assert not relative.is_absolute() and '..' not in relative.parts
    current=ROOT
    for part in relative.parts:
        current=current/part
        assert not current.is_symlink(), f'symlink path: {value}'
    assert current.is_file(), f'missing file: {value}'
    assert current.stat().st_size>0, f'empty file: {value}'
    return current


def within(value,ranges):
    path=Path(value)
    return any(path==Path(scope) or Path(scope) in path.parents for scope in ranges)


state=json.loads((ROOT/'.game-design/state/parallel.json').read_text())
protected=[ROOT/'Brief.md']
for task in TASKS:
    protected.append(ROOT/f'orders/{task}.json')
    protected.extend(p for p in (ROOT/'Evidence'/task).rglob('*') if p.is_file())
protected.extend(p for p in (ROOT/'Design').rglob('*') if p.is_file())
before={str(p.relative_to(ROOT)):sha(p) for p in protected}
observed={};authors={}
for task in TASKS:
    order=json.loads(local(f'orders/{task}.json').read_text())
    result=json.loads(local(f'Evidence/{task}/result.json').read_text())
    frozen=state['tasks'][task]
    assert order['workspace']==str(ROOT)
    assert order['effect']=='design' and state['mode']=='design-only'
    assert result['task_id']==order['id']==task
    assert result['claim_token']==order['claim_token']==frozen['claim_token']
    assert result['status']=='submitted'
    assert frozen['run_id'] and frozen['run_id']!=ACTOR
    authors[task]=frozen['run_id']
    for name,digest in order['input_hashes'].items():
        assert sha(local(name))==digest==frozen['input_hashes'][name], 'frozen input drift: '+name
    artifacts={}
    for artifact in result['artifacts']:
        name=artifact['path']
        assert within(name,order['writes']), 'out-of-scope artifact: '+name
        digest=sha(local(name))
        assert digest==artifact['sha256']==frozen['artifact_hashes'][name]
        artifacts[name]=digest
    assert set(order['outputs'])<=artifacts.keys(), 'missing declared output'
    evidence={item['path']:item['sha256'] for item in frozen['result']['verified_evidence']}
    assert set(result['evidence'])==evidence.keys()
    for name,digest in evidence.items():
        assert within(name,order['writes'])
        assert sha(local(name))==digest, 'collected evidence drift: '+name
    assert result['tests'] and all(t['status']=='pass' and t['exit_status']==0 for t in result['tests'])
    observed[task]={'artifacts':artifacts,'evidence':evidence,'brief_sha256':sha(ROOT/'Brief.md')}
    print(f'PASS {task}: bound author {frozen["run_id"]}; input/scope/output/artifact/evidence hashes match live project')
assert len(set(authors.values()))==2

# Re-run reviewed author scripts without editing their original logs or outputs.
for script in ('Evidence/design-loop/check_spec.py','Evidence/design-level/validate_level.py'):
    command=['python3',script]
    result=subprocess.run(command,cwd=ROOT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},text=True,capture_output=True)
    assert result.returncode==0,result.stderr+result.stdout
    print(json.dumps({'independent_rerun_command':command,'cwd':str(ROOT),'stdin':'','stdout':result.stdout,
                      'stderr':result.stderr,'exit_status':result.returncode},ensure_ascii=False))

core=(ROOT/'Design/core-loop.md').read_text();level=(ROOT/'Design/level-outline.md').read_text()
assert 'player=(row,col)' in core and '`x` 向右增加、`y` 向下增加' in level
assert '不允许拉箱' in core and '没有拉箱命令或自动拉回行为' in level
assert 'history=[]' in core and '清空撤销历史' in level
assert 'crate==goal' in core and '箱子坐标等于目标坐标' in level
assert '方向动作只在won=false时处理' in core
assert '移动是否冻结由核心循环规格统一决定' in level
print('PASS coordinate integration: level (x,y) maps to core (row,col)=(y,x); all direction deltas agree')
print('PASS semantic integration: push-only/no-pull; crate-on-goal success; undo/reset; core owns post-win input freeze')

grid=re.search(r'```grid\n(.*?)\n```',level,re.S).group(1).splitlines()
sequence=re.search(r'Solution: `([^`]+)`',level).group(1).split()
points=lambda symbol:[(row,col) for row,line in enumerate(grid) for col,char in enumerate(line) if char==symbol]
assert all(len(points(symbol))==1 for symbol in '@$G')
start_player=points('@')[0];start_crate=points('$')[0];goal=points('G')[0];walls=set(points('#'))
delta={'U':(-1,0),'R':(0,1),'D':(1,0),'L':(0,-1)}

class IntegratedRules:
    def __init__(self):self.reset()
    def reset(self):
        self.player=start_player;self.crate=start_crate;self.move_count=0;self.history=[];self.won=self.crate==goal
    def snapshot(self):return self.player,self.crate,self.move_count,self.won
    def move(self,key):
        if self.won:return False
        dr,dc=delta[key];target=(self.player[0]+dr,self.player[1]+dc)
        if not (0<=target[0]<len(grid) and 0<=target[1]<len(grid[0])) or target in walls:return False
        crate=self.crate
        if target==crate:
            crate=(crate[0]+dr,crate[1]+dc)
            if not (0<=crate[0]<len(grid) and 0<=crate[1]<len(grid[0])) or crate in walls:return False
        self.history.append(self.snapshot());self.player=target;self.crate=crate;self.move_count+=1;self.won=self.crate==goal
        return True
    def undo(self):
        if not self.history:return False
        self.player,self.crate,self.move_count,self.won=self.history.pop();return True

m=IntegratedRules()
assert (m.player,m.crate,goal)==((4,2),(2,3),(3,4))
for step,key in enumerate(sequence,1):
    assert m.move(key);assert m.won==(step==len(sequence));assert m.move_count==step
assert m.crate==goal and m.player==(2,4) and len(m.history)==6
winning=m.snapshot();assert not m.move('U') and m.snapshot()==winning
assert m.undo() and m.snapshot()==((1,4),(2,4),5,False)
m.reset();initial=m.snapshot();assert not m.history and not m.undo() and m.snapshot()==initial
assert m.move('U');blocked=(m.snapshot(),list(m.history));assert not m.move('R') and (m.snapshot(),m.history)==blocked
m.reset()
for key in 'UUUR':assert m.move(key)
blocked=(m.snapshot(),list(m.history));assert not m.move('D') and (m.snapshot(),m.history)==blocked
m.reset()
for key in 'UURL':assert m.move(key)
assert m.player==(2,2) and m.crate==(2,4)
print('PASS independent integrated-rule simulation: route, one-step push/history, win freeze, undo full state, reset, blocked walk/push, no-pull')
assert before=={str(p.relative_to(ROOT)):sha(p) for p in protected}, 'author/brief/order bytes changed during integration'
print('PASS read-only integration: Brief/orders/Design/author evidence and scripts remain byte-identical')
print(json.dumps({'integrator_run_id':ACTOR,'tasks':{task:'pass' for task in TASKS},'observed_hashes':observed,
                  'coordinate_adapter':'(row,col)=(y,x)',
                  'scope':'document + independent Python design-rule simulation; no engine/game/DCC/device execution',
                  'runtime_validation':'not_run'},ensure_ascii=False,indent=2))
