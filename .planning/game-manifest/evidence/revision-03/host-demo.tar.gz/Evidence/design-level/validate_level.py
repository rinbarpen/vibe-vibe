"""Design-rule simulation fixture only; no engine or game window is executed."""
from pathlib import Path
import re

text=Path('Design/level-outline.md').read_text(encoding='utf-8')
grid=re.search(r'```grid\n(.*?)\n```',text,re.S).group(1).splitlines()
sequence=re.search(r'Solution: `([^`]+)`',text).group(1).split()
assert len(grid)==7 and all(len(row)==8 for row in grid)
assert all(c in '#.@$G' for row in grid for c in row)
assert all(c=='#' for c in grid[0]+grid[-1])
assert all(row[0]==row[-1]=='#' for row in grid)
points=lambda symbol:[(x,y) for y,row in enumerate(grid) for x,c in enumerate(row) if c==symbol]
assert all(len(points(symbol))==1 for symbol in '@$G')
start_player=points('@')[0];start_crate=points('$')[0];goal=points('G')[0]
walls=set(points('#'));delta={'U':(0,-1),'D':(0,1),'L':(-1,0),'R':(1,0)}

class Model:
    def __init__(self):self.reset()
    def reset(self):self.player=start_player;self.crate=start_crate;self.history=[]
    def move(self,key):
        dx,dy=delta[key];x,y=self.player;nxt=(x+dx,y+dy)
        if nxt in walls:return False
        crate=self.crate
        if nxt==crate:
            target=(crate[0]+dx,crate[1]+dy)
            if target in walls:return False
            crate=target
        self.history.append((self.player,self.crate))
        self.player=nxt;self.crate=crate
        return True
    def undo(self):
        if not self.history:return False
        self.player,self.crate=self.history.pop();return True
    @property
    def won(self):return self.crate==goal

for required in ('坐标与图例','可复现解法','失败与重试验收','交接与验证边界'):
    assert required in text
print('PASS grid: 8x7, sealed boundary, one player/crate/goal')
m=Model();assert (m.player,m.crate,goal)==((2,4),(3,2),(4,3))
for index,key in enumerate(sequence,1):
    assert m.move(key)
    assert m.won==(index==len(sequence))
    print(f'step {index}: {key} player={m.player} crate={m.crate} won={m.won}')
assert (m.player,m.crate)==((4,2),(4,3))
print('PASS solution: U U R U R D reaches the goal')
assert m.undo() and (m.player,m.crate)==((4,1),(4,2)) and not m.won
print('PASS undo: restores pre-winning player/crate state')
m.reset();assert (m.player,m.crate)==(start_player,start_crate) and not m.history and not m.won
print('PASS reset: restores initial state and clears history')
assert m.move('U');before=(m.player,m.crate,list(m.history));assert not m.move('R')
assert before==(m.player,m.crate,m.history)
print('PASS blocked walk: wall leaves state/history unchanged')
m.reset()
for key in 'UUUR':assert m.move(key)
before=(m.player,m.crate,list(m.history));assert not m.move('D')
assert before==(m.player,m.crate,m.history)
print('PASS blocked push: wall behind crate leaves state/history unchanged')
m.reset()
for key in 'UURL':assert m.move(key)
assert m.player==(2,2) and m.crate==(4,2)
print('PASS no-pull: walking away does not move the crate')
print('7 design-rule checks passed; engine/game/device validation = not_run')
