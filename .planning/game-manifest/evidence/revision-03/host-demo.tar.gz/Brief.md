# Host subagent integration fixture
This is a design-document orchestration exercise, not a finished game.
Concept: a tiny 2D grid crate-pushing puzzle. One player, offline, keyboard.
A level has walls, floor, one crate and one goal. The player pushes but does not pull.
Success is crate on goal; reset and undo are required. No art, engine, or DCC execution.
